﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Part_2_ST10480263
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private CyberBotLogic BotLogic;

        public MainWindow()
        {
            InitializeComponent();

            BotLogic = new CyberBotLogic();
        } 

        private void AddMessage(string sender, string message, bool isUser)
        {
            // Outer stack panel to hold the time and the bubble layout row
            StackPanel messageRowStack = new StackPanel
            {
                HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(0, 4, 0, 4)
            };

            // Timestamp 
            TextBlock timeTextBlock = new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                Foreground = Brushes.LightGray,
                FontSize = 11,
                HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(5, 0, 5, 2)
            };

            // The Speech Bubble Border Container
            Border bubbleBorder = new Border
            {
                CornerRadius = new CornerRadius(15),
                Padding = new Thickness(12),
                MaxWidth = 420,
                // Swaps colors dynamically based on who is speaking
                Background = isUser ? Brushes.CadetBlue : Brushes.DarkSlateBlue
            };


            TextBlock msgTextBlock = new TextBlock
            {
                Text = $"{sender}: {message}",
                Foreground = Brushes.White,
                FontSize = 14,
                TextWrapping = TextWrapping.Wrap
            };


            bubbleBorder.Child = msgTextBlock;

            messageRowStack.Children.Add(timeTextBlock);
            messageRowStack.Children.Add(bubbleBorder);

            // Push into the main UI container and force view focus to the bottom
            chatFeedPanel.Children.Add(messageRowStack);
            chatScrollViewer.ScrollToBottom();

        }

        private void btnSubmitName_Click(object sender, RoutedEventArgs e)
        {
            string InputName = txtUserName.Text.Trim();

            if (string.IsNullOrWhiteSpace(InputName)) return;

            lblInitial.Text = InputName.Substring(0, 1).ToUpper();

            AddMessage("CyberBot", "Welcome to the Secure Terminal, " + InputName, isUser: false);
            AddMessage("CyberBot", "How can I help you stay safe today?", isUser: false);
            AddMessage("CyberBot", "If you're lost try asking me about these topics:", isUser: false);
            AddMessage("CyberBot", " > [PASSWORDS] - How to create unhackable logins.", isUser: false);
            AddMessage("CyberBot", " > [PHISHING]  - How to spot fake emails and scams.", isUser: false);
            AddMessage("CyberBot", " > [BROWSING]  - How to stay safe on the web.", isUser: false);

        }

        private void btnSendQuery_Click(object sender, RoutedEventArgs e)
        {
            string query = txtQueryInput.Text.Trim();


            if (string.IsNullOrWhiteSpace(query)) return;

            // Add User Message on the right side
            AddMessage("You", query, isUser: true);

            // THE DELEGATE CONNECTION
            ChatProcessor processor = new ChatProcessor(BotLogic.GetResponse);
            string botResponse = processor(query);

            // Add Bot Message on the left side
            AddMessage("CyberBot", botResponse, isUser: false);

            // Clear input panel and return focus for the next typing sequence
            txtQueryInput.Clear();
            txtQueryInput.Focus();

        }
    }
}
