﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Part_2_ST10480263
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private void AddMessage(string sender, string message, bool isUser)
        {
            // Outer stack panel to hold the time and the bubble layout row
            StackPanel messageRowStack = new StackPanel
            {
                HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(0, 4, 0, 4)
            };

            // Timestamp 
            TextBlock timeTextBlock = new TextBlock
            {
                Text = DateTime.Now.ToString("HH:mm"),
                Foreground = Brushes.LightGray,
                FontSize = 11,
                HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                Margin = new Thickness(5, 0, 5, 2)
            };

            // The Speech Bubble Border Container
            Border bubbleBorder = new Border
            {
                CornerRadius = new CornerRadius(15),
                Padding = new Thickness(12),
                MaxWidth = 420,
                // Swaps colors dynamically based on who is speaking
                Background = isUser ? Brushes.CadetBlue : Brushes.DarkSlateBlue
            };


            TextBlock msgTextBlock = new TextBlock
            {
                Text = $"{sender}: {message}",
                Foreground = Brushes.White,
                FontSize = 14,
                TextWrapping = TextWrapping.Wrap
            };


            bubbleBorder.Child = msgTextBlock;

            messageRowStack.Children.Add(timeTextBlock);
            messageRowStack.Children.Add(bubbleBorder);

            // Push into the main UI container and force view focus to the bottom
            chatFeedPanel.Children.Add(messageRowStack);
            chatScrollViewer.ScrollToBottom();

        }

        private void btnSubmitName_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
