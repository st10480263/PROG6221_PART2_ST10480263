﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Part_2_ST10480263
{
    public delegate string ChatProcessor(string userInput);
    public class CyberBotLogic
    {
        


    }
}

