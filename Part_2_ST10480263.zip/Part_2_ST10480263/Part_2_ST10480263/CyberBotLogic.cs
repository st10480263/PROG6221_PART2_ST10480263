﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Part_2_ST10480263
{
    public delegate string ChatProcessor(string userInput);
    public class CyberBotLogic
    {
        private Dictionary<string, string> knowledgeBase;
        private List<string> phishingTips;
        private List<string> passwordTips;

        private string lastTopic = "";
        private string favoriteTopic = "";
        private Random randomizer = new Random();

        public CyberBotLogic()
        {

            knowledgeBase = new Dictionary<string, string>
            {
                { "browse", "Safe browsing means checking for HTTPS and avoiding sensitive public networks." },
                { "browsing", "Safe browsing means checking for HTTPS and avoiding sensitive public networks." }
            };


            phishingTips = new List<string>
            {
                "Be cautious of emails asking for urgent personal info. Scammers disguise themselves as trusted brands.",
                "Always check the sender's actual email domain, not just the display name. Look for typos.",
                "Never click on unexpected links. Navigate to the official organization website manually."
            };

            passwordTips = new List<string>
            {
                "Safety tip: Use a passphrase of 4+ random words. It's much harder to brute-force.",
                "Never reuse the same password across multiple accounts. Use a password manager.",
                "Enable Multi-Factor Authentication (MFA) on all accounts to secure your data."
            };

        }

        public string GetResponse(string User_Input)
        {

            string UserPrompt = User_Input?.ToLower().Trim() ?? "";
            string ResponsePrefix = "";

            //Input validation to check if the input given is a null value

            if (string.IsNullOrWhiteSpace(UserPrompt))
            {
                return ("Please ask a question about security.");
            }

            if (UserPrompt.Contains("worried") || UserPrompt.Contains("scared") || UserPrompt.Contains("hacked"))
            {
                ResponsePrefix = "It's completely understandable to feel that way. Online threats can be daunting. Let me share some safety measures with you: \n\n";
            }
            else if (UserPrompt.Contains("frustrated") || UserPrompt.Contains("annoyed") || UserPrompt.Contains("tired"))
            {
                ResponsePrefix = "I get your frustration. Security protocols can feel like a hassle, but staying protected keeps your data safe. Here is a helpful tip: \n\n";
            }
            else if (UserPrompt.Contains("curious") || UserPrompt.Contains("interested"))
            {
                ResponsePrefix = "Excellent! Curiosity is the best tool for staying ahead of hackers. Check this out: \n\n";
            }

            if (UserPrompt.Contains("interested in") || UserPrompt.Contains("focus on") || UserPrompt.Contains("want to learn about"))
            {
                if (UserPrompt.Contains("privacy"))
                {
                    favoriteTopic = "privacy";
                }

                else

                if (UserPrompt.Contains("phishing") || UserPrompt.Contains("scam"))
                {
                    favoriteTopic = "phishing";
                }

                else

                if (UserPrompt.Contains("password"))
                {
                    favoriteTopic = "password";
                }

                if (!string.IsNullOrEmpty(favoriteTopic))
                {
                    return $"Great! I'll remember that you are particularly interested in {favoriteTopic}. It's a crucial part of staying safe online. Try asking me for a tip about it!";
                }
            }


            //Switch statement to check the user input in order to provide the right responses using specific keywords
            switch (UserPrompt)
            {
                case "how are you":

                    return "I'm doing well, thanks for asking!";

                case string s when s.Contains("password"):

                    lastTopic = "password";
                    return ResponsePrefix + passwordTips[randomizer.Next(passwordTips.Count)];

                case string s when s.Contains("phishing") || s.Contains("scam"):

                    lastTopic = "phishing";
                    return ResponsePrefix + phishingTips[randomizer.Next(phishingTips.Count)];

                case string s when s.Contains("another") || s.Contains("more") || s.Contains("explain"):

                    if (lastTopic == "phishing")
                    {
                        return ResponsePrefix + phishingTips[randomizer.Next(phishingTips.Count)];
                    }
                    else

                    if (lastTopic == "password")
                    {
                        return ResponsePrefix + passwordTips[randomizer.Next(passwordTips.Count)];
                    }

                    else

                        return "What topic would you like me to expand on? Try asking about passwords or phishing.";

                default:

                    foreach (var key in knowledgeBase.Keys)
                    {
                        if (UserPrompt.Contains(key))
                        {
                            lastTopic = key;
                            return ResponsePrefix + knowledgeBase[key];
                        }
                    }

                    return "I'm sorry, I don't know how to help with That. Try asking about passwords or safe browsing.";

            }

        }

    }
}


